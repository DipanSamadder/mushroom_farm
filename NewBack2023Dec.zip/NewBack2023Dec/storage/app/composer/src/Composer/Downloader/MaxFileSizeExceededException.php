<?php declare(strict_types=1);











namespace Composer\Downloader;

class MaxFileSizeExceededException extends TransportException
{
}
