<?php declare(strict_types=1);











namespace Composer\Installer;

class InstallerEvents
{








public const PRE_OPERATIONS_EXEC = 'pre-operations-exec';
}
