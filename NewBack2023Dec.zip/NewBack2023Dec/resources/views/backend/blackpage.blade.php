@extends('backend.layouts.app')

{{-- Header section--}}
@section('header')

@endsection

{{-- Content section--}}
@section('content')

@endsection

{{-- Footer section--}}
@section('footer')

@endsection