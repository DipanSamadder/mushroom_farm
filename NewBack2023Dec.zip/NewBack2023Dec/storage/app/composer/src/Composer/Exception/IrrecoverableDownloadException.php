<?php declare(strict_types=1);











namespace Composer\Exception;




class IrrecoverableDownloadException extends \RuntimeException
{
}
