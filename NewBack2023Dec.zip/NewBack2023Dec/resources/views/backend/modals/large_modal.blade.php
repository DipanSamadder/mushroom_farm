<div class="modal fade" id="larger_modals" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="title" id="larger_modals_tile"></h4>
            </div>
            <div class="modal-body">
                <div id="large_modals_body">
                </div>
            </div>
        </div>
    </div>
</div>